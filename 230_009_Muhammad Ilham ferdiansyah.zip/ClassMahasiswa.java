/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Mahasiswa;

import java.util.Scanner;
 
     
 
public class Mahasiswa {
    

    class data{
        String nama;
        String nim;
        String asalsekolah;
        String ttl;
        String prodi;
        String alamat;
        
    public static tampilan data{
        
        System.out.println("Data Mahasiswa");
        System.out.println("Nama : " + nama);
        
    }
    
}
    public static void main(String[] args) {
        System.out.println("Masukkan Namanya : ");
        nama = input.nextLine;
        System.out.println("Masukkan NIM : ");
        nim = input.nextLine;
        System.out.println("Masukkan Asal Sekolah Anda :");
        asalsekolah = input.nextLine;
        System.out.println("Masukkan Tempat Tanggal Lahir :");
        String ttl = input.nextLine;
        System.out.println("Masukkan Prodi : ");
        System.out.println("SI : SISTEM INFORMASI");
        System.out.println("TIF : TEKNIK INFORMATIKA");
        System.out.println("TI : TEKNIK INDUSTRI");
        System.out.println("TM : TEKNIK MESIN");
        System.out.println("TMK : TEKNIK MEKATRONIKA");
        System.out.println("TE : TEKNIK ELEKTRO");
        prodi = input.nextLine;
        System.out.println("Masukan alamat anda : ");
        alamat = input.nextLine;
        
        if ttl == "SI"{
            data.tampilan()
        }
        else if {
            
      }  
    }
    
